const products=[{"name": "MANTA-X", "price": 50000, "image": "https://via.placeholder.com/300x200?text=MANTA-X"}, {"name": "Panel Minecraft", "price": 10000, "image": "https://via.placeholder.com/300x200?text=Panel"}, {"name": "Script Bot", "price": 25000, "image": "https://via.placeholder.com/300x200?text=Script+Bot"}];
let cart=[];

const list=document.getElementById('products');
products.forEach((p,i)=>{
 list.innerHTML+=`<div class="card">
 <img src="${p.image}" alt="">
 <h3>${p.name}</h3>
 <p class="price">Rp${p.price.toLocaleString('id-ID')}</p>
 <button onclick="add({i})">Tambah</button></div>`;
});

function add(i){
 cart.push(products[i]);
 update();
}

function update(){
 document.getElementById('cartCount').textContent=cart.length;
 document.getElementById('cartItems').innerHTML=cart.map(x=>`<li>${x.name} - Rp${x.price.toLocaleString('id-ID')}</li>`).join('');
 document.getElementById('total').textContent='Rp'+cart.reduce((a,b)=>a+b.price,0).toLocaleString('id-ID');
}

function toggleCart(){document.getElementById('cart').classList.toggle('hidden')}
document.getElementById('cartBtn').onclick=toggleCart;
